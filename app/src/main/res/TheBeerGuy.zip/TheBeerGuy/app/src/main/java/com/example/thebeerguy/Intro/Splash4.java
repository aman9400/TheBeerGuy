package com.example.thebeerguy.Intro;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.thebeerguy.Login;
import com.example.thebeerguy.R;


public class Splash4 extends Fragment {
    Button sp4_btn_login, sp4_btn_signup;
    TabLayout tabLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_splash4, container, false);


//        ((LinearLayout) tabLayout.getTabAt(0).view).setVisibility(View.GONE);

        sp4_btn_login = view.findViewById(R.id.sp4_btn_login);
        sp4_btn_signup = view.findViewById(R.id.sp4_btn_signup);

        sp4_btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sp4_loginIntent = new Intent(getContext(), Login.class);
                startActivity(sp4_loginIntent);
            }
        });

        sp4_btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sp4_signupIntent = new Intent(getContext(), Login.class);
                startActivity(sp4_signupIntent);

            }
        });





        return view;
    }
}