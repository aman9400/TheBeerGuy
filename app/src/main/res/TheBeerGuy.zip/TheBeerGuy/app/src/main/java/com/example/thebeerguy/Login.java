package com.example.thebeerguy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.Forget.ForgotPassword;
import com.example.thebeerguy.DashBoard.DashBoard;
import com.example.thebeerguy.DashBoard.Home;

public class Login extends AppCompatActivity {

    Button login_btn_login;
    TextView login_Tv_signup;
    TextView login_Tv_forgetPassword;
    EditText login_email, login_password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        login_Tv_signup = findViewById(R.id.login_Tv_signup);
        login_Tv_forgetPassword = findViewById(R.id.login_Tv_forgetPassword);
        login_email = findViewById(R.id.login_email);
        login_password = findViewById(R.id.login_password);
        login_btn_login = findViewById(R.id.login_btn_login);



        login_btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               }
        });


        login_Tv_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent login_signupIntent = new Intent(Login.this, SignUp.class);
                startActivity(login_signupIntent);
            }
        });

        login_Tv_forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent login_forgetPassIntent = new Intent(Login.this, ForgotPassword.class);
                startActivity(login_forgetPassIntent);
            }
        });
    }
}