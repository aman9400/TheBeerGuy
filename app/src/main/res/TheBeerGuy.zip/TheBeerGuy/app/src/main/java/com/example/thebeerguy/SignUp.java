package com.example.thebeerguy;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.ClientError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.thebeerguy.DashBoard.Home;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {

     TextView signup_Tv_login;
     Button signup_button_signup;
    private ImageButton signup_btn_back;
    EditText sign_mobile, sign_email, sign_name,sign_password, sign_address,sign_apt,sign_buzzer, sign_extraInfo;

    public final String postUrl ="https://sandbox.tbg.api.tweak.tbg.delivery/customer/create/";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().hide();

        findIds();

        signup_button_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sign_password.getText().toString().isEmpty() && sign_mobile.getText().toString().isEmpty()
                        && sign_email.getText().toString().isEmpty() && sign_name.getText().toString().isEmpty()){
                    Toast.makeText(SignUp.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                }else{
                    signupApi();
                }
            }
        });

        signup_Tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signup_login = new Intent(SignUp.this, Login.class);
                startActivity(signup_login);
            }
        });

        signup_btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signup_backIntent = new Intent(SignUp.this, Login.class);
                startActivity(signup_backIntent);
            }
        });

    }

        private void signupApi() {

            String url = postUrl;

            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, response -> {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    int string = jsonObject.getInt("success");
                    String mes = jsonObject.getString("message");
                    if (string == 0) {

                        sign_email.setError("Email already used");
                        Toast.makeText(SignUp.this, "" + mes, Toast.LENGTH_LONG).show();
                    } else {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        String accessToken = jsonObject1.getString("access_token");
                        Intent intent = new Intent(SignUp.this, Home.class);
                        intent.putExtra("screen", "email");
                        intent.putExtra("token", accessToken);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }, error -> {

                if (error instanceof NetworkError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle your network error here.
                } else if (error instanceof ServerError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle if server error occurs with 5** status code
                } else if (error instanceof AuthFailureError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle if authFailure occurs.This is generally because of invalid credentials
                } else if (error instanceof ParseError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle if the volley is unable to parse the response data.
                } else if (error instanceof NoConnectionError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle if no connection is occurred
                } else if (error instanceof TimeoutError) {
                    Toast.makeText(SignUp.this, "" + error, Toast.LENGTH_SHORT).show();
                    //handle if socket time out is occurred.
                } else if (error instanceof ClientError) {
                    Toast.makeText(SignUp.this, "number already exist", Toast.LENGTH_SHORT).show();

                }
//            Toast.makeText(this, ""+error, Toast.LENGTH_SHORT).show();
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> map = new HashMap<>();
                    map.put("registration", "1");
                    map.put("first_name", sign_name.getText().toString());
                    map.put("mobile", sign_mobile.getText().toString());
                    map.put("email", sign_email.getText().toString());
                    map.put("address",sign_address.getText().toString());

                    map.put("device_token", "1122334");
                    map.put("device_type", "1");
                    return map;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> map = new HashMap<>();
                    map.put("Content-Type", "application/x-www-form-urlencoded");
//                map.put("Content-Length","<calculated when request is sent>");
                    map.put("accept", "application/json");
                    return map;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(SignUp.this);
            requestQueue.add(stringRequest);
        }

        private void findIds() {

            signup_button_signup = findViewById(R.id.signup_button_signup);
            signup_Tv_login = findViewById(R.id.signup_Tv_login);
            signup_btn_back = findViewById(R.id.signup_btn_back);
            sign_mobile = findViewById(R.id.sign_mobile);
            sign_password = findViewById(R.id.sign_password);
            sign_address = findViewById(R.id.sign_address);
            sign_apt = findViewById(R.id.sign_apt);
            sign_buzzer = findViewById(R.id.sign_buzzer);
            sign_extraInfo = findViewById(R.id.sign_extrainfo);
            sign_email = findViewById(R.id.sign_email);
            sign_name = findViewById(R.id.sign_name);


        }

}