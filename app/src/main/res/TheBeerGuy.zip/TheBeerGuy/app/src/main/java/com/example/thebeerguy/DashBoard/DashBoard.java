package com.example.thebeerguy.DashBoard;

import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.thebeerguy.R;

public class DashBoard extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);


        setFragment(new Home());
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener((BottomNavigationView.OnNavigationItemSelectedListener) item -> {

            switch (item.getItemId()) {
                case R.id.theBeerGuy_home: {
                    setFragment(new Home());
                    break;
                }

                case R.id.theBeerGuy_fav: {
                    setFragment(new Favourites());
                    break;
                }

                case R.id.theBeerGuy_recent: {
                    setFragment(new Recent());
                    break;
                }

                case R.id.theBeerGuy_order: {
                    setFragment(new Orders());
                    break;
                }

                case R.id.theBeerGuy_account: {
                    setFragment(new Account());
                    break;
                }



                default:
                    Toast.makeText(this, "wrong choice", Toast.LENGTH_SHORT).show();
            }

            return true;
        });

    }

    void setFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_dash, fragment).commit();
    }


}