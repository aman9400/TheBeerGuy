package com.example.Forget;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.thebeerguy.Login;
import com.example.thebeerguy.R;

public class ForgotPassword extends AppCompatActivity {

    Button forgetPassword_btn_send;
    ImageButton forgetPassword_btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().hide();

        forgetPassword_btn_send = findViewById(R.id.forgetPassword_btn_send);
        forgetPassword_btn_back = findViewById(R.id.forgetPassword_btn_back);

        forgetPassword_btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgetPass_backIntent = new Intent(ForgotPassword.this, Login.class);
                startActivity(forgetPass_backIntent);
            }
        });

        forgetPassword_btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forget_sendIntent = new Intent(ForgotPassword.this, PasswordRecovery.class);
                startActivity(forget_sendIntent);
            }
        });

    }
}