package com.example.thebeerguy.DashBoard.NavigationDrawerItems;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.thebeerguy.R;

public class NavContactUs extends AppCompatActivity {
    WebView nav_contactus_webView;

    private final String postUrl ="https://www.thebeerguy.ca/contact_us/";
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_contact_us);

        nav_contactus_webView = findViewById(R.id.nav_contactus_webView);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        nav_contactus_webView.loadUrl(postUrl);
        WebSettings webSettings = nav_contactus_webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        nav_contactus_webView.setWebViewClient(new WebViewClient());
        nav_contactus_webView.setWebChromeClient(new WebChromeClient());

        progressDialog.dismiss();

    }
}