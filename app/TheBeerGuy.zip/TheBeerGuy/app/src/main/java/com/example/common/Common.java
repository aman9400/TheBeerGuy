package com.example.common;

public class Common {

    public static String Apikey_text = "api_key";

    public static String Apikey_value = "codewraps-app-dev";

    public static String jwt = "codewraps-app-dev";


}
