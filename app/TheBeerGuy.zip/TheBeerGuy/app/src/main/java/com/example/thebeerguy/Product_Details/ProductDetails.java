package com.example.thebeerguy.Product_Details;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.Apis.APIClient;
import com.example.Apis.APIInterface;
import com.example.common.Common;
import com.example.common.CommonMethod;
import com.example.thebeerguy.DashBoard.Home.Adapters.GridAdapter;
import com.example.thebeerguy.DashBoard.Home.Adapters.WhatsHotAdapter;
import com.example.thebeerguy.DashBoard.ResponseJson.homeResponse.ResponseHome;
import com.example.thebeerguy.Product_Details.ProductDetailsResponse.ResponseProductDetail;
import com.example.thebeerguy.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetails extends AppCompatActivity {

    GridView productDetail_grid;
    private List<ResponseHome> list = new ArrayList<>();
    private TextView product_arrow_down, product_TV_price, product_TV_name,
            product_TV_ratting, product_TV_time, product_TV_rating2,
            product_TV_discription, product_brewer, product_alcohol;

    private List<ResponseHome> productDetailsList = new ArrayList<>();



    private ImageView product_IV_image;
    private String productID;
    private String type_id;
    private String cat_id;

    APIInterface apiInterface;
    private ProgressDialog progressDialog;


    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        findIds();

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        apiInterface = APIClient.getClient().create(APIInterface.class);



        productID = getIntent().getStringExtra("productID");
        String name = getIntent().getStringExtra("name");
        type_id = getIntent().getStringExtra("type");
        cat_id = getIntent().getStringExtra("cat");


        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"#ffffff\">" + name+ "</font>"));


//        getSupportActionBar().show();
//        getSupportActionBar().setTitle(name);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);


        productApi();


        product_arrow_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Dialog dialog = new Dialog(ProductDetails.this);
                dialog.setContentView(R.layout.product_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);

                TextView product_cancle_btn;
                RadioGroup product_radioGroup;
                RadioButton product_radioButton1, product_radioButton2, product_radioButton3;

                product_cancle_btn = dialog.findViewById(R.id.product_cancle_btn);
                product_radioGroup = dialog.findViewById(R.id.product_radioGroup);
                product_radioButton1 = dialog.findViewById(R.id.product_radioButton1);
                product_radioButton2 = dialog.findViewById(R.id.product_radioButton2);
                product_radioButton3 = dialog.findViewById(R.id.product_radioButton3);


                product_cancle_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                dialog.show();

            }
        });


        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        ProductDetailsGridAPI("is_popular", "1");


//        modelListSimilar();
//
//
//        BeerAdapter adapter = new BeerAdapter(this, list);
//        productDetail_recycler.setHasFixedSize(true);
//        productDetail_recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//        productDetail_recycler.setAdapter(adapter);


    }

    private void findIds() {

        product_arrow_down = findViewById(R.id.product_arrow_down);
        product_IV_image = findViewById(R.id.product_IV_image);
        product_TV_price = findViewById(R.id.product_TV_price);
        product_TV_name = findViewById(R.id.product_TV_name);
        product_TV_ratting = findViewById(R.id.product_TV_ratting);
        product_TV_time = findViewById(R.id.product_TV_time);
        product_TV_rating2 = findViewById(R.id.product_TV_rating2);
        product_alcohol = findViewById(R.id.product_alcohol);
        product_brewer = findViewById(R.id.product_brewer);
        product_TV_discription = findViewById(R.id.product_TV_discription);
        productDetail_grid = findViewById(R.id.productDetail_grid);

    }

    private void modelListSimilar() {

//        list.add(new SampleModel(R.drawable.beer, "Budweiser", "$2.90 - $104.95", "1"));
//        list.add(new SampleModel(R.drawable.vodka, "Budweiser", "$2.90 - $104.95", "2"));
//        list.add(new SampleModel(R.drawable.beer, "Budweiser", "$2.90 - $104.95", "3"));
//        list.add(new SampleModel(R.drawable.vodka, "Budweiser", "$2.90 - $104.95", "4"));
    }


    private void productApi() {

        boolean networkCheck = CommonMethod.isNetworkAvailable(this);
        if (!networkCheck) {
            Toast.makeText(this, "check network", Toast.LENGTH_SHORT).show();
        } else {
            Map<String, String> map = new
                    HashMap<>();
            map.put(Common.Apikey_text, Common.Apikey_value);
            map.put("product_id", productID);
            map.put("category_id", cat_id);
            map.put("type_id", type_id);



            Call<ResponseProductDetail> call1 = apiInterface.productDetail(map);

            call1.enqueue(new Callback<ResponseProductDetail>() {
                @Override
                public void onResponse(Call<ResponseProductDetail> call, Response<ResponseProductDetail> response) {
                    if (response.isSuccessful()) {
                        ResponseProductDetail responseProductDetail = response.body();
//                            Common.jwt = responseSignup.getJwt();
//                            Log.e("response : " , String.valueOf(response));
//                            Toast.makeText(SignUp.this, "Signup Successful", Toast.LENGTH_SHORT).show();

//                            startActivity(new Intent(SignUp.this, Login.class));


                        Picasso.get().load(responseProductDetail.getImage()).into(product_IV_image);
                        product_TV_name.setText(responseProductDetail.getLabel());
                        product_TV_ratting.setText(responseProductDetail.getRating());
                        product_brewer.setText(responseProductDetail.getBrewer());
                        product_alcohol.setText(responseProductDetail.getAlcoholContent());


                    } else {
                        Toast.makeText(ProductDetails.this, "Data not found", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<ResponseProductDetail> call, Throwable t) {
                    Toast.makeText(ProductDetails.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void ProductDetailsGridAPI(String typeKey, String typeID) {

        boolean networkCheck = CommonMethod.isNetworkAvailable(getApplication());
        if (networkCheck) {

            Map<String, String> map = new HashMap<>();
            map.put(Common.Apikey_text, Common.Apikey_value);
            map.put(typeKey, typeID);
            map.put("is_topten", "1");
//                map.put(typeID"skin_id", "2");

            Call<List<ResponseHome>> call1 = apiInterface.home(map);

            call1.enqueue(new Callback<List<ResponseHome>>() {
                @Override
                public void onResponse(Call<List<ResponseHome>> call, Response<List<ResponseHome>> response) {
                    if (response.isSuccessful()) {
                        List<ResponseHome> loginResponse = response.body();

                        progressDialog.dismiss();
                        productDetailsList = response.body();

                        GridAdapter gridAdapter = new GridAdapter(ProductDetails.this, productDetailsList);
                        productDetail_grid.setAdapter(gridAdapter);
//                            whatsHotApi("is_popular", "1");


//                            Toast.makeText(getContext(), "Beer list", Toast.LENGTH_SHORT).show();

//                            startActivity(new Intent(getContext(), DashBoard.class));
                    } else {
                        Toast.makeText(ProductDetails.this, "No Data found", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<List<ResponseHome>> call, Throwable t) {
                    Toast.makeText(ProductDetails.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            });

        } else {
            Toast.makeText(ProductDetails.this, "Please Check your internet.", Toast.LENGTH_SHORT).show();
        }

    }


}