package com.example.thebeerguy.DashBoard.NavigationDrawerItems;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.thebeerguy.R;

public class NavDeliveryRate extends AppCompatActivity {

    private final String postUrl ="https://www.thebeerguy.ca/help/delivery_rates/";

    private WebView nav_deliveryRate_webview;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_delivery_rate);

        nav_deliveryRate_webview = findViewById(R.id.nav_deliveryRate_webview);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        nav_deliveryRate_webview.loadUrl(postUrl);
        WebSettings webSettings = nav_deliveryRate_webview.getSettings();
        webSettings.setJavaScriptEnabled(true);
        nav_deliveryRate_webview.setWebViewClient(new WebViewClient());
        nav_deliveryRate_webview.setWebChromeClient(new WebChromeClient());

        progressDialog.dismiss();
    }
}