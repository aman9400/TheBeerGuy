package com.example.thebeerguy.DashBoard;


import com.example.thebeerguy.R;

public class Constant {
    public static final String[] nav_menu_txt = {
//           "Login", "Home", "Logout"
    };
    public static final int[] nav_menu_icon = {
//          R.drawable.loginuser,  R.drawable.beerguy_home,  R.drawable.logout

    };

}